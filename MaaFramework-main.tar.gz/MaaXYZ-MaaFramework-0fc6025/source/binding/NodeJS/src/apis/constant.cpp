#include "loader.h"

#include <MaaFramework/MaaAPI.h>

#include "../foundation/spec.h"

#define DE(prefix, key) obj[#key] = maajs::JSConvert<prefix>::to_value(env, prefix##Enum::prefix##_##key)
#define DEM(prefix, key) obj[#key] = maajs::JSConvert<prefix>::to_value(env, prefix##_##key)

static maajs::ValueType load_status(maajs::EnvType env)
{
    auto obj = maajs::ObjectType::New(env);

    DE(MaaStatus, Invalid);
    DE(MaaStatus, Pending);
    DE(MaaStatus, Running);
    DE(MaaStatus, Succeeded);
    DE(MaaStatus, Failed);

    return obj;
}

static maajs::ValueType load_adb_screencap_method(maajs::EnvType env)
{
    auto obj = maajs::ObjectType::New(env);

    DEM(MaaAdbScreencapMethod, EncodeToFileAndPull);
    DEM(MaaAdbScreencapMethod, Encode);
    DEM(MaaAdbScreencapMethod, RawWithGzip);
    DEM(MaaAdbScreencapMethod, RawByNetcat);
    DEM(MaaAdbScreencapMethod, MinicapDirect);
    DEM(MaaAdbScreencapMethod, MinicapStream);
    DEM(MaaAdbScreencapMethod, EmulatorExtras);
    DEM(MaaAdbScreencapMethod, All);
    DEM(MaaAdbScreencapMethod, Default);

    return obj;
}

static maajs::ValueType load_adb_input_method(maajs::EnvType env)
{
    auto obj = maajs::ObjectType::New(env);

    DEM(MaaAdbInputMethod, AdbShell);
    DEM(MaaAdbInputMethod, MinitouchAndAdbKey);
    DEM(MaaAdbInputMethod, Maatouch);
    DEM(MaaAdbInputMethod, EmulatorExtras);
    DEM(MaaAdbInputMethod, All);
    DEM(MaaAdbInputMethod, Default);

    return obj;
}

static maajs::ValueType load_win32_screencap_method(maajs::EnvType env)
{
    auto obj = maajs::ObjectType::New(env);

    DEM(MaaWin32ScreencapMethod, GDI);
    DEM(MaaWin32ScreencapMethod, FramePool);
    DEM(MaaWin32ScreencapMethod, DXGI_DesktopDup);
    DEM(MaaWin32ScreencapMethod, DXGI_DesktopDup_Window);
    DEM(MaaWin32ScreencapMethod, PrintWindow);
    DEM(MaaWin32ScreencapMethod, ScreenDC);
    DEM(MaaWin32ScreencapMethod, All);
    DEM(MaaWin32ScreencapMethod, Foreground);
    DEM(MaaWin32ScreencapMethod, Background);

    return obj;
}

static maajs::ValueType load_win32_input_method(maajs::EnvType env)
{
    auto obj = maajs::ObjectType::New(env);

    DEM(MaaWin32InputMethod, Seize);
    DEM(MaaWin32InputMethod, SendMessage);
    DEM(MaaWin32InputMethod, PostMessage);
    DEM(MaaWin32InputMethod, LegacyEvent);
    DEM(MaaWin32InputMethod, PostThreadMessage);
    DEM(MaaWin32InputMethod, SendMessageWithCursorPos);
    DEM(MaaWin32InputMethod, PostMessageWithCursorPos);
    DEM(MaaWin32InputMethod, SendMessageWithWindowPos);
    DEM(MaaWin32InputMethod, PostMessageWithWindowPos);
    DEM(MaaWin32InputMethod, Interception);
    DEM(MaaWin32InputMethod, AnchoredTouch);

    return obj;
}

static maajs::ValueType load_gamepad_type(maajs::EnvType env)
{
    auto obj = maajs::ObjectType::New(env);

    DEM(MaaGamepadType, Xbox360);
    DEM(MaaGamepadType, DualShock4);

    return obj;
}

static maajs::ValueType load_gamepad_button(maajs::EnvType env)
{
    auto obj = maajs::ObjectType::New(env);

    // Xbox 360 buttons
    DEM(MaaGamepadButton, DPAD_UP);
    DEM(MaaGamepadButton, DPAD_DOWN);
    DEM(MaaGamepadButton, DPAD_LEFT);
    DEM(MaaGamepadButton, DPAD_RIGHT);
    DEM(MaaGamepadButton, START);
    DEM(MaaGamepadButton, BACK);
    DEM(MaaGamepadButton, LEFT_THUMB);
    DEM(MaaGamepadButton, RIGHT_THUMB);
    DEM(MaaGamepadButton, LB);
    DEM(MaaGamepadButton, RB);
    DEM(MaaGamepadButton, GUIDE);
    DEM(MaaGamepadButton, A);
    DEM(MaaGamepadButton, B);
    DEM(MaaGamepadButton, X);
    DEM(MaaGamepadButton, Y);

    // DS4 face buttons (aliases, same values as Xbox)
    DEM(MaaGamepadButton, CROSS);
    DEM(MaaGamepadButton, CIRCLE);
    DEM(MaaGamepadButton, SQUARE);
    DEM(MaaGamepadButton, TRIANGLE);
    DEM(MaaGamepadButton, L1);
    DEM(MaaGamepadButton, R1);
    DEM(MaaGamepadButton, L3);
    DEM(MaaGamepadButton, R3);
    DEM(MaaGamepadButton, OPTIONS);
    DEM(MaaGamepadButton, SHARE);

    // DS4 special buttons
    DEM(MaaGamepadButton, PS);
    DEM(MaaGamepadButton, TOUCHPAD);

    return obj;
}

static maajs::ValueType load_gamepad_contact(maajs::EnvType env)
{
    auto obj = maajs::ObjectType::New(env);

    DEM(MaaGamepadTouch, LeftStick);
    DEM(MaaGamepadTouch, RightStick);
    DEM(MaaGamepadTouch, LeftTrigger);
    DEM(MaaGamepadTouch, RightTrigger);

    return obj;
}

static maajs::ValueType load_macos_screencap_method(maajs::EnvType env)
{
    auto obj = maajs::ObjectType::New(env);

    DEM(MaaMacOSScreencapMethod, ScreenCaptureKit);

    return obj;
}

static maajs::ValueType load_macos_input_method(maajs::EnvType env)
{
    auto obj = maajs::ObjectType::New(env);

    DEM(MaaMacOSInputMethod, GlobalEvent);
    DEM(MaaMacOSInputMethod, PostToPid);

    return obj;
}

static maajs::ValueType load_linux_screencap_method(maajs::EnvType env)
{
    auto obj = maajs::ObjectType::New(env);

    DEM(MaaLinuxScreencapMethod, Wlr);
    DEM(MaaLinuxScreencapMethod, ExtImage);
    DEM(MaaLinuxScreencapMethod, PipeWire);

    return obj;
}

static maajs::ValueType load_linux_input_method(maajs::EnvType env)
{
    auto obj = maajs::ObjectType::New(env);

    DEM(MaaLinuxInputMethod, Wlr);
    DEM(MaaLinuxInputMethod, UInput);
    DEM(MaaLinuxInputMethod, Libei);

    return obj;
}

std::map<std::string, maajs::ValueType> load_constant(maajs::EnvType env)
{
    return {
        { "Status", load_status(env) },
        { "AdbScreencapMethod", load_adb_screencap_method(env) },
        { "AdbInputMethod", load_adb_input_method(env) },
        { "Win32ScreencapMethod", load_win32_screencap_method(env) },
        { "Win32InputMethod", load_win32_input_method(env) },
        { "MacOSScreencapMethod", load_macos_screencap_method(env) },
        { "MacOSInputMethod", load_macos_input_method(env) },
        { "LinuxScreencapMethod", load_linux_screencap_method(env) },
        { "LinuxInputMethod", load_linux_input_method(env) },
        { "GamepadType", load_gamepad_type(env) },
        { "GamepadButton", load_gamepad_button(env) },
        { "GamepadContact", load_gamepad_contact(env) },
    };
}
