#include "MaaAgent/Transceiver.h"

#include <algorithm>
#include <cctype>
#include <cerrno>
#include <cstdlib>
#include <format>
#include <fstream>
#include <optional>
#include <string_view>
#include <utility>

#ifdef _WIN32
#include "MaaUtils/SafeWindows.hpp"
// afunix.h 在旧版 SDK 中可能不存在，直接定义 AF_UNIX 常量
#ifndef AF_UNIX
#define AF_UNIX 1
#endif
#endif

#include "MaaUtils/Platform.h"
#include "MaaUtils/ScopeLeave.hpp"
#include "MaaUtils/StringMisc.hpp"
#include "MaaUtils/Uuid.h"

MAA_AGENT_NS_BEGIN

Transceiver::~Transceiver()
{
    LogFunc;

    uninit_socket();
}

bool Transceiver::handle_image_header(const json::value& j)
{
    if (!j.is<ImageHeader>()) {
        return false;
    }

    const ImageHeader& header = j.as<ImageHeader>();

    LogTrace << VAR(header) << VAR(ipc_addr_);

    handle_image(header);

    return true;
}

bool Transceiver::handle_image_encoded_header(const json::value& j)
{
    if (!j.is<ImageEncodedHeader>()) {
        return false;
    }

    const ImageEncodedHeader& header = j.as<ImageEncodedHeader>();

    LogTrace << VAR(header) << VAR(ipc_addr_);

    handle_image_encoded(header);

    return true;
}

static std::string temp_directory()
{
#ifndef _WIN32
    auto path = std::filesystem::temp_directory_path();
#else
    // https://github.com/MaaEnd/MaaEnd/issues/95
    // 测了写权限了还不行，我没招了，直接拉💩
    auto path = MaaNS::path("C:/Temp");

    if (!std::filesystem::exists(path)) {
        std::error_code ec;
        std::filesystem::create_directories(path, ec);
    }
#endif

    return path_to_utf8_string(path);
}

static std::optional<uint16_t> parse_port_string(std::string_view port_str)
{
    if (port_str.empty()) {
        return std::nullopt;
    }

    bool all_digits = std::all_of(port_str.begin(), port_str.end(), [](unsigned char c) { return std::isdigit(c) != 0; });
    if (!all_digits) {
        return std::nullopt;
    }

    char* end = nullptr;
    unsigned long port = std::strtoul(port_str.data(), &end, 10);
    if (end != port_str.data() + port_str.size() || port == 0 || port > 65535) {
        return std::nullopt;
    }

    return static_cast<uint16_t>(port);
}

void Transceiver::create_pair_socket()
{
    zmq_sock_ = zmq::socket_t(zmq_ctx_, zmq::socket_type::pair);
    zmq_pollitem_send_ = zmq::pollitem_t(zmq_sock_.handle(), 0, ZMQ_POLLOUT, 0);
    zmq_pollitem_recv_ = zmq::pollitem_t(zmq_sock_.handle(), 0, ZMQ_POLLIN, 0);
}

void Transceiver::init_socket(const std::string& identifier, bool bind)
{
    LogFunc << VAR(bind);

    static auto kTempDir = temp_directory();

    std::string path = std::format("{}/maafw-agent-{}.sock", kTempDir, identifier);
    ipc_addr_ = std::format("ipc://{}", path);
    ipc_path_ = MaaNS::path(path);
    is_tcp_ = false;

    LogInfo << VAR(ipc_addr_) << VAR(identifier);

    create_pair_socket();

    is_bound_ = bind;

    if (is_bound_) {
        zmq_sock_.bind(ipc_addr_);
    }
    else {
        zmq_sock_.connect(ipc_addr_);
    }
}

static uint16_t parse_port_from_endpoint(const std::string& endpoint)
{
    // endpoint 格式为 "tcp://127.0.0.1:12345"
    auto pos = endpoint.rfind(':');
    if (pos == std::string::npos || pos >= endpoint.size() - 1) {
        return 0;
    }

    return parse_port_string(std::string_view(endpoint).substr(pos + 1)).value_or(0);
}

std::optional<uint16_t> Transceiver::parse_tcp_port(const std::string& identifier)
{
    return parse_port_string(identifier);
}

uint16_t Transceiver::init_tcp_socket(uint16_t port, bool bind)
{
    LogFunc << VAR(port) << VAR(bind);

    is_tcp_ = true;

    create_pair_socket();

    is_bound_ = bind;

    if (is_bound_) {
        // 如果 port 为 0，使用通配符让系统自动分配端口
        std::string bind_addr = std::format("tcp://127.0.0.1:{}", port == 0 ? "*" : std::to_string(port));
        zmq_sock_.bind(bind_addr);

        // 获取实际绑定的端点
        char endpoint[256] = { };
        size_t endpoint_len = sizeof(endpoint);
        zmq_getsockopt(zmq_sock_.handle(), ZMQ_LAST_ENDPOINT, endpoint, &endpoint_len);
        ipc_addr_ = endpoint;

        tcp_port_ = parse_port_from_endpoint(ipc_addr_);
        LogInfo << "TCP socket bound" << VAR(ipc_addr_) << VAR(tcp_port_);
    }
    else {
        ipc_addr_ = std::format("tcp://127.0.0.1:{}", port);
        tcp_port_ = port;
        zmq_sock_.connect(ipc_addr_);
        LogInfo << "TCP socket connected" << VAR(ipc_addr_);
    }

    return tcp_port_;
}

bool Transceiver::should_fallback_to_tcp()
{
    LogFunc;

#ifdef _WIN32
    // Windows 从 Build 17063 开始支持 AF_UNIX (Unix Domain Socket)
    // 直接尝试创建 socket 来检测系统是否支持，比检测版本号更可靠

    static std::optional<bool> cached_result;
    if (cached_result.has_value()) {
        return *cached_result;
    }

    // 需要先初始化 Winsock，否则 socket() 会失败
    WSADATA wsa_data;
    int wsa_result = WSAStartup(MAKEWORD(2, 2), &wsa_data);
    if (wsa_result != 0) {
        LogWarn << "WSAStartup failed, falling back to TCP" << VAR(wsa_result);
        cached_result = true;
        return true;
    }

    SOCKET test_sock = socket(AF_UNIX, SOCK_STREAM, 0);
    if (test_sock == INVALID_SOCKET) {
        int err = WSAGetLastError();
        WSACleanup();
        // WSAEAFNOSUPPORT (10047) 表示地址族不支持
        LogWarn << "AF_UNIX socket not supported on this Windows version, falling back to TCP" << VAR(err);
        cached_result = true;
        return true;
    }

    closesocket(test_sock);
    WSACleanup();
    cached_result = false;

    LogInfo << "AF_UNIX socket supported on this Windows version";
    return false;
#else
    // 非 Windows 系统通常 IPC 工作正常
    LogInfo << "IPC supported on this system";
    return false;
#endif
}

void Transceiver::uninit_socket()
{
    LogFunc << VAR(ipc_addr_);

    // if (connected()) {
    //     if (is_bound_) {
    //         zmq_sock_.unbind(ipc_addr_);
    //     }
    //     else {
    //         zmq_sock_.disconnect(ipc_addr_);
    //     }
    // }

    // AgentClient owns the bound socket and may be destroyed without a disconnect handshake.
    if (is_bound_) {
        zmq_sock_.set(zmq::sockopt::linger, 0);
    }

    zmq_sock_.close();
    zmq_ctx_.close();

    // TCP 模式无需删除 socket 文件
    if (!is_tcp_) {
        std::error_code ec;
        std::filesystem::remove(ipc_path_, ec);
    }
}

void Transceiver::reset_socket(std::chrono::milliseconds linger)
{
    std::unique_lock lock(socket_mutex_);

    zmq_sock_.set(zmq::sockopt::linger, static_cast<int>(linger.count()));
    zmq_sock_.close();

    if (is_bound_ && !is_tcp_) {
        std::error_code ec;
        std::filesystem::remove(ipc_path_, ec);
    }

    zmq_ctx_.close(); // 同步等待 socket 销毁完成
    zmq_ctx_ = zmq::context_t();

    create_pair_socket();

    if (is_bound_) {
        zmq_sock_.bind(ipc_addr_);
    }
    else {
        zmq_sock_.connect(ipc_addr_);
    }
}

bool Transceiver::alive()
{
    std::unique_lock lock(socket_mutex_);
    return zmq_sock_.handle() != nullptr && zmq::detail::poll(&zmq_pollitem_send_, 1, 0);
}

void Transceiver::set_timeout(const std::chrono::milliseconds& timeout)
{
    LogInfo << VAR(timeout) << VAR(ipc_addr_);
    // This timeout controls Transceiver::poll and therefore survives socket recreation.
    timeout_ = timeout;
}

bool Transceiver::poll(zmq::pollitem_t& pollitem)
{
    const auto start_clock = std::chrono::steady_clock::now();

    while (true) {
        auto elapsed = duration_since(start_clock);
        auto remaining_time = timeout_ > elapsed ? timeout_ - elapsed : std::chrono::milliseconds(0);
        auto interval = std::min(remaining_time, std::chrono::milliseconds(1000));

        try {
            if (zmq::poll(&pollitem, 1, interval)) {
                return true;
            }
        }
        catch (const zmq::error_t& e) {
            // Android/Linux: signals may interrupt poll; retry with remaining timeout.
            if (e.num() != EINTR) {
                throw;
            }
        }

        if (elapsed > timeout_) {
            LogWarn << "socket is not alive" << VAR(elapsed) << VAR(timeout_) << VAR(ipc_addr_);
            return false;
        }
    }
    // unreachable code
    // return false;
}

bool Transceiver::send(const json::value& j)
{
    // LogTrace << VAR(j.to_string()) << VAR(ipc_addr_);

    std::unique_lock lock(socket_mutex_);

    if (!poll(zmq_pollitem_send_)) {
        LogError << "send canceled";
        return false;
    }

    const bool tag =
        !s_handling_requests_.empty() && s_handling_requests_.back().owner == this && s_handling_requests_.back().req_id && is_response(j);
    if (!tag) {
        return send_impl(j);
    }

    json::value tagged = j;
    tagged[kRespIdKey] = *s_handling_requests_.back().req_id;
    return send_impl(tagged);
}

bool Transceiver::is_response(const json::value& j)
{
    // 消息靠 _XxxResponse / _XxxRequest 占位字段区分类型
    if (!j.is_object()) {
        return false;
    }
    return std::ranges::any_of(j.as_object(), [](const auto& kv) { return kv.first.starts_with('_') && kv.first.ends_with("Response"); });
}

std::optional<json::value> Transceiver::send_and_recv_impl(json::value req, bool (*is_untagged_response)(const json::value&))
{
    const int64_t req_id = ++s_req_id_;

    {
        std::unique_lock lock(pending_mutex_);
        pending_responses_.emplace(req_id, std::nullopt);
    }
    // poll() 可能抛异常，任何退出路径都要注销
    OnScopeLeave([&]() {
        std::unique_lock lock(pending_mutex_);
        pending_responses_.erase(req_id);
    });

    // LogFunc << VAR(req_id);
    req[kReqIdKey] = req_id;
    bool sent = send(req);
    if (!sent) {
        LogError << "failed to send req" << VAR(req_id);
        return std::nullopt;
    }

    for (int64_t loop_count = 0;; ++loop_count) {
        // LogTrace << "enter loop" << VAR(req_id) << VAR(loop_count);

        if (auto pending = take_pending_response(req_id)) {
            return pending;
        }

        auto msg_opt = recv();
        if (!msg_opt) {
            LogError << "failed to recv resp" << VAR(req_id) << VAR(loop_count);
            return std::nullopt;
        }
        json::value& msg = *msg_opt;
        if (auto resp_id = msg.find<int64_t>(kRespIdKey)) {
            if (*resp_id == req_id) {
                return std::move(msg);
            }
            // 嵌套等待时外层请求的回包可能先落到内层循环里
            stash_response(*resp_id, std::move(msg));
            continue;
        }
        if (is_untagged_response(msg)) {
            // LogTrace << "response" << VAR(req_id) << VAR(loop_count);
            return std::move(msg);
        }
        else if (msg.is<ImageHeader>()) {
            handle_image(msg.as<ImageHeader>());
        }
        else if (msg.is<ImageEncodedHeader>()) {
            handle_image_encoded(msg.as<ImageEncodedHeader>());
        }
        else {
            // LogTrace << "inserted request" << VAR(req_id) << VAR(loop_count);
            dispatch_inserted_request(msg);
        }
    }
    // unreachable code
    // return std::nullopt;
}

std::optional<json::value> Transceiver::take_pending_response(int64_t req_id)
{
    std::unique_lock lock(pending_mutex_);

    auto it = pending_responses_.find(req_id);
    if (it == pending_responses_.end()) {
        return std::nullopt;
    }
    return std::exchange(it->second, std::nullopt);
}

void Transceiver::stash_response(int64_t resp_id, json::value msg)
{
    std::unique_lock lock(pending_mutex_);

    // 超时放弃、异常退出或对端乱发的编号都没人再取，不暂存
    auto it = pending_responses_.find(resp_id);
    if (it == pending_responses_.end()) {
        LogWarn << "drop stale response" << VAR(resp_id) << VAR(ipc_addr_);
        return;
    }
    it->second = std::move(msg);
}

bool Transceiver::dispatch_inserted_request(const json::value& j)
{
    s_handling_requests_.push_back({ .owner = this, .req_id = j.find<int64_t>(kReqIdKey) });

    struct PopGuard
    {
        ~PopGuard() { s_handling_requests_.pop_back(); }
    } pop_guard;

    return handle_inserted_request(j);
}

bool Transceiver::send_no_wait(const json::value& j)
{
    std::unique_lock lock(socket_mutex_);
    return send_impl(j);
}

bool Transceiver::send_impl(const json::value& j)
{
    std::string jstr = j.dumps();
    zmq::message_t msg(jstr.data(), jstr.size());

    bool sent = zmq_sock_.send(std::move(msg), zmq::send_flags::dontwait).has_value();
    if (!sent) {
        LogError << "failed to send msg" << VAR(j);
        return false;
    }
    return true;
}

std::optional<json::value> Transceiver::recv()
{
    std::unique_lock lock(socket_mutex_);

    if (!poll(zmq_pollitem_recv_)) {
        LogError << "recv canceled";
        return std::nullopt;
    }

    zmq::message_t msg;

    auto size_opt = zmq_sock_.recv(msg, zmq::recv_flags::dontwait);
    if (!size_opt || *size_opt == 0) {
        LogError << "failed to recv msg" << VAR(ipc_addr_);
        return std::nullopt;
    }

    std::string_view init_str = msg.to_string_view();
    auto jopt = json::parse(init_str);
    if (!jopt) {
        LogError << "failed to parse msg" << VAR(ipc_addr_);
        return std::nullopt;
    }
    auto j = *std::move(jopt);
    // LogTrace << VAR(j.to_string()) << VAR(ipc_addr_);

    return j;
}

std::string Transceiver::send_image(const cv::Mat& mat)
{
    if (mat.empty()) {
        LogWarn << "empty image" << VAR(ipc_addr_);
        return { };
    }

    std::unique_lock lock(socket_mutex_);

    ImageHeader header {
        .uuid = make_uuid(),
        .rows = mat.rows,
        .cols = mat.cols,
        .type = mat.type(),
        .size = mat.total() * mat.elemSize(),
    };

    // send header
    if (!poll(zmq_pollitem_send_)) {
        LogError << "send header canceled";
        return { };
    }
    std::string jstr = json::value(header).dumps();
    zmq::message_t header_msg(jstr.data(), jstr.size());
    bool sent = zmq_sock_.send(std::move(header_msg), zmq::send_flags::dontwait).has_value();
    if (!sent) {
        LogError << "failed to send header" << VAR(header) << VAR(ipc_addr_);
        return { };
    }

    // send image data
    zmq::message_t img_msg(mat.data, mat.total() * mat.elemSize());
    sent = zmq_sock_.send(img_msg, zmq::send_flags::none).has_value();
    if (!sent) {
        LogError << "failed to send msg" << VAR(ipc_addr_);
        return { };
    }
    return header.uuid;
}

std::string Transceiver::send_image_encoded(const ImageEncodedBuffer& encoded_data)
{
    if (encoded_data.empty()) {
        LogWarn << "empty encoded data" << VAR(ipc_addr_);
        return { };
    }

    std::unique_lock lock(socket_mutex_);

    ImageEncodedHeader header {
        .uuid = make_uuid(),
        .size = encoded_data.size(),
    };

    // send header
    if (!poll(zmq_pollitem_send_)) {
        LogError << "send encoded header canceled";
        return { };
    }
    std::string jstr = json::value(header).dumps();
    zmq::message_t header_msg(jstr.data(), jstr.size());
    bool sent = zmq_sock_.send(std::move(header_msg), zmq::send_flags::dontwait).has_value();
    if (!sent) {
        LogError << "failed to send encoded header" << VAR(header) << VAR(ipc_addr_);
        return { };
    }

    // send encoded image data
    zmq::message_t img_msg(encoded_data.data(), encoded_data.size());
    sent = zmq_sock_.send(img_msg, zmq::send_flags::none).has_value();
    if (!sent) {
        LogError << "failed to send encoded image data" << VAR(ipc_addr_);
        return { };
    }
    return header.uuid;
}

cv::Mat Transceiver::get_image_cache(const std::string& uuid)
{
    if (uuid.empty()) {
        LogWarn << "empty uuid" << VAR(ipc_addr_);
        return { };
    }

    auto it = recved_images_.find(uuid);
    if (it == recved_images_.end()) {
        LogError << "image not found" << VAR(uuid) << VAR(ipc_addr_);
        return { };
    }

    cv::Mat image = std::move(it->second);
    recved_images_.erase(it);

    return image;
}

Transceiver::ImageEncodedBuffer Transceiver::get_image_encoded_cache(const std::string& uuid)
{
    if (uuid.empty()) {
        // LogWarn << "empty uuid" << VAR(ipc_addr_);
        return { };
    }

    auto it = recved_images_encoded_.find(uuid);
    if (it == recved_images_encoded_.end()) {
        LogError << "encoded image not found" << VAR(uuid) << VAR(ipc_addr_);
        return { };
    }

    ImageEncodedBuffer encoded_data = std::move(it->second);
    recved_images_encoded_.erase(it);

    return encoded_data;
}

void Transceiver::handle_image(const ImageHeader& header)
{
    LogFunc << VAR(header);

    std::unique_lock lock(socket_mutex_);

    zmq::message_t msg;
    auto size_opt = zmq_sock_.recv(msg);
    if (!size_opt || *size_opt == 0) {
        LogError << "failed to recv msg" << VAR(ipc_addr_);
        return;
    }

    if (header.size != msg.size()) {
        LogError << "size mismatch" << VAR(header.size) << VAR(msg.size());
        return;
    }

    cv::Mat image = cv::Mat(header.rows, header.cols, header.type, msg.data()).clone();
    recved_images_.insert_or_assign(header.uuid, std::move(image));
}

void Transceiver::handle_image_encoded(const ImageEncodedHeader& header)
{
    LogFunc << VAR(header);

    std::unique_lock lock(socket_mutex_);

    zmq::message_t msg;
    auto size_opt = zmq_sock_.recv(msg);
    if (!size_opt || *size_opt == 0) {
        LogError << "failed to recv encoded image data" << VAR(ipc_addr_);
        return;
    }

    if (header.size != msg.size()) {
        LogError << "encoded size mismatch" << VAR(header.size) << VAR(msg.size());
        return;
    }

    ImageEncodedBuffer encoded_data(static_cast<const uint8_t*>(msg.data()), static_cast<const uint8_t*>(msg.data()) + msg.size());
    recved_images_encoded_.insert_or_assign(header.uuid, std::move(encoded_data));
}

MAA_AGENT_NS_END
