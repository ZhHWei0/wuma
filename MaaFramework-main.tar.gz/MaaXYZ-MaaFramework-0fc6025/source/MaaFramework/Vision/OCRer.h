#pragma once

#include <mutex>
#include <ostream>
#include <string>
#include <unordered_map>
#include <vector>

#include <boost/regex.hpp>

#include "Common/Conf.h"

#include "MaaUtils/Encoding.h"
#include "MaaUtils/JsonExt.hpp"
#include "OCRSession.h"
#include "VisionBase.h"
#include "VisionTypes.h"

MAA_VISION_NS_BEGIN

struct OCRerResult
{
    std::wstring text;
    cv::Rect box { };
    double score = 0.0;

    MEO_JSONIZATION(text, box, score);
};

struct ColorFilterConfig
{
    int method = ColorMatcherParam::kDefaultMethod;
    std::vector<ColorMatcherParam::Range> range;
};

class OCRer
    : public VisionBase
    , public RecoResultAPI<OCRerResult>
{
public:
    OCRer(
        cv::Mat image,
        std::vector<cv::Rect> rois,
        OCRerParam param,
        OCRSessionPtr session,
        std::string name = "",
        std::optional<ColorFilterConfig> color_filter = std::nullopt);

    OCRer(
        cv::Mat image,
        std::vector<cv::Rect> rois,
        OCRerParam param,
        const ResultsVec& cached,
        OCRSessionPtr session,
        std::string name = "");

private:
    void analyze();

    ResultsVec predict() const;
    ResultsVec handle_cached() const;

    void add_results(ResultsVec results, const std::vector<std::wstring>& expected);
    void cherry_pick();

private:
    cv::Mat apply_color_filter(const cv::Mat& image_roi) const;
    ResultsVec predict_det_and_rec(const cv::Mat& image_roi) const;
    Result predict_only_rec(const cv::Mat& image_roi) const;
    ResultsVec predict_batch_rec(const std::vector<cv::Rect>& rois) const;

    cv::Mat draw_result(const ResultsVec& results) const;

    void postproc_trim_(Result& res) const;
    void postproc_replace_(Result& res) const;
    bool filter_by_required(const Result& res, const std::vector<std::wstring>& expected) const;
    void sort_(ResultsVec& results) const;

private:
    static const boost::wregex& gen_regex(const std::wstring& pattern);

private:
    const OCRerParam param_;
    const std::optional<ColorFilterConfig> color_filter_;

    std::optional<ResultsVec> cache_;

    OCRSessionPtr session_ = nullptr;

    inline static std::mutex s_predict_mutex_;
};

struct OCRCache
{
    // Batch results are only valid for OCR requests compatible with this model.
    std::string model;
    std::unordered_map<std::string, OCRer::ResultsVec> results;
};

MAA_VISION_NS_END
